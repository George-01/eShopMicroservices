﻿namespace Catalog.API.Products.CreateProduct
{
    public class CreateProductEndpoint
    {
    }
}
